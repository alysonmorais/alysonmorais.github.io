#!/bin/bash
######################################################################################################################
# DEFINIR UNIDADE DE TEMPO DE ACORDO COM PARAMETROS DO COMANDO FIND; EXEMPLO: -ctime PARA DIAS OU -cmin PARA MINUTOS;
UNIT=-cmin
# DEFINIR QUANTIDADE DE DIAS OU UNIDADE DE TEMPO DEFINIDA NA VARIAVEL $UNIT;
VALUE=+3
# DEFINIR CAMINHO COMPLETO DA DIRETÓRIO DA LIXEIRA;
TRASH_DIR=/srv/samba/trash
# DEFINIR CAMINHO COMPLETO DO ARQUIVO DE LOG;
LOG_FILE=/root/trash.log
# DEFINIR AÇÃO A SER REALIZADA PELO COMANDO FIND; O PADRÃO É EXCLUIR (comando rm -fv);
ACTION="rm -fv"
######################################################################################################################

echo " " >>$LOG_FILE
echo "INICIANDO LIMPEZA DA LIXEIRA EM `date +%d`/`date +%m`/`date +%Y` ÀS `date +%T` HORAS..." >>$LOG_FILE
echo " " >>$LOG_FILE

echo "EXCLUINDO DEFINITIVAMENTE ARQUIVOS ENVIADOS PARA A LIXEIRA HÁ MAIS DE ${VALUE} MINUTOS..." >>$LOG_FILE
echo "-------------------------------------------------------------------------------------------" >>$LOG_FILE
find ${TRASH_DIR} ${UNIT} ${VALUE} -type f -exec ${ACTION} {} \; &>>$LOG_FILE
echo "-------------------------------------------------------------------------------------------" >>$LOG_FILE
echo " " >>$LOG_FILE
echo "===========================================================================================" >>$LOG_FILE

exit 2
