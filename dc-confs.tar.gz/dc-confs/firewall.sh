#!/bin/bash
PATH='/sbin'

# CONFIGURE A VARIAVEL "LAN" COM A FAIXA DE IP DA SUA REDE LOCAL. EX.: "192.168.0.0/24"
LAN="172.16.0.0/24"

if [ "$#" -ne 1 ]
then 
		
		echo "Quantidade de parâmetros incorreta! Use: firewall.sh <start/stop>"
		exit 1
		
fi

# general firewall rules
inicia() {

		iptables -F
		iptables -X
		iptables -t nat -F
		iptables -t nat -X
		iptables -t mangle -F
		iptables -t mangle -X

	# LIBERA ACESSO VIA SSH 
		iptables -A INPUT -p tcp -s ${LAN} --dport 22 -j ACCEPT

	# LIBERA PING
		iptables -A INPUT -p icmp -s ${LAN} -j ACCEPT

	# PORTAS TCP DE USO DOS SERVIÇOS DO SAMBA 
		iptables -A INPUT -p tcp -s ${LAN} -m multiport --dport 53,88,135,139,389,445,636,1024:5000,3268,3269,5353 -j ACCEPT
		iptables -A INPUT -p tcp -s ${LAN} -m multiport --dport 49152:65535,3268,3269,5353 -j ACCEPT

	# PORTAS UDP DE USO DOS SERVIÇOS DO SAMBA
		iptables -A INPUT -p UDP -s ${LAN} -m multiport --dport 137,138,53,88,389,464,5353,123 -j ACCEPT

	# REGRAS QUE PERMITEM PACOTES DE CONEXÕES JÁ ESTABELECIDAS
		iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
		iptables -A OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
		iptables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT


	# REGRAS DE BLOQUEIO PARA QUALQUER TIPO CONEXÃO NÃO PERMITIDA NAS REGRAS ACIMA
		iptables -A INPUT -j DROP
		iptables -A OUTPUT -j ACCEPT
		iptables -A FORWARD -j DROP

}

# clean firewall rules
finaliza() {
		
		iptables -P INPUT ACCEPT
		iptables -F
		iptables -X
		iptables -t nat -F
		iptables -t nat -X
		iptables -t mangle -F
		iptables -t mangle -X

}

case $1 in
	# firewall rules when system starts up
	start)
	
		inicia
		echo "Firewall inicializado com sucesso!"
		exit 0

	;;
	# firewall rules when system down (clear rules)
	stop)
		
		finaliza
		echo "Firewall finalizado com sucesso!"
		exit 0

	;;
	# 
	*)
		echo "Opção inválida! Use: firewall.sh <start/stop>"
		exit 1

	;;
esac
